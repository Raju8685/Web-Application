const sentences = [
    "This is a sample sentence jumbling game",
    "JavaScript is fun to learn",
    "Web development is exciting",
    "Have you got much going on these days?",
    "How’s your workday looking?",
    "Should we grab a bite to eat?",
    "Would you like to grab a coffee this afternoon?",
    "Have you fed the dogs?",
    "What do you want to do?",
    "Can I make you some coffee?"
];

let currentSentenceIndex = 0;
let score = 0;

const jumbledSentenceDiv = document.getElementById("jumbled-sentence");
const userSentenceInput = document.getElementById("user-sentence");
const checkButton = document.getElementById("check-button");
const resultDiv = document.getElementById("result");
const scoreSpan = document.getElementById("score");
const nextButton = document.getElementById("next-button");

function loadNextSentence() {
    if (currentSentenceIndex < sentences.length) {
        const jumbledSentence = sentences[currentSentenceIndex];
        const sentenceArray = jumbledSentence.split(" ");
        const jumbledArray = sentenceArray.sort(() => Math.random() - 0.5);

        jumbledSentenceDiv.textContent = jumbledArray.join(" ");
        userSentenceInput.value = "";
        resultDiv.textContent = "";
        nextButton.style.display = "none";
        checkButton.disabled = false;
    } else {
        jumbledSentenceDiv.textContent = "Game Over!";
        userSentenceInput.style.display = "none";
        checkButton.style.display = "none";
        nextButton.style.display = "none";
    }
}

loadNextSentence();

checkButton.addEventListener("click", () => {
    const userSentence = userSentenceInput.value.trim();
    const correctSentence = sentences[currentSentenceIndex];

    if (userSentence === correctSentence) {
        resultDiv.textContent = "Correct!";
        score++;
        scoreSpan.textContent = score;
    } else {
        resultDiv.textContent = "Incorrect. Try again.";
    }

    checkButton.disabled = true;
    nextButton.style.display = "block";
});

nextButton.addEventListener("click", () => {
    currentSentenceIndex++;
    if (currentSentenceIndex < sentences.length) {
        loadNextSentence();
    }
});
