<?php
$host = 'localhost';
$root = 'root';
$pass = '';
$data_base = 'main';

$conn = new mysqli($host, $root, $pass, $data_base);

if ($conn->connect_error) {
    die('Connection interrupted!...Try Again' . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if form fields are set
    if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['phoneno']) && isset($_POST['email'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $phoneno = $_POST['phoneno'];
        $email = $_POST['email'];

    // You should also perform input validation and sanitation here

    // Insert the user data into the database
    $sql = "INSERT INTO signup (username, password, phoneno, email) VALUES ('$username', '$password', '$phoneno', '$email')";

    if ($conn->query($sql) === TRUE) {
        // Redirect to the login page after successful registration
        header("Location: index.html");
        exit;
        echo "Registration successful!";
    } else {
        // Handle the case where form fields are not set
        echo "All fields are required!";
    }
}

}
$conn->close();
?>
