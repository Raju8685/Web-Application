<?php
$host = 'localhost';
$root = 'root';
$pass = '';
$data_base = 'main';

$conn = new mysqli($host, $root, $pass, $data_base);

if ($conn->connect_error) {
    die('Connection interrupted!...Try Again' . $conn->connect_error);
}

$useri = $conn->real_escape_string($_POST['username']); // Use 'username' instead of 'root'
$userp = $conn->real_escape_string($_POST['password']); // Use 'password'


$sql = "SELECT * FROM signup WHERE username='$useri' AND password='$userp'";
$response = mysqli_query($conn, $sql);

if ($response) {
    if (mysqli_num_rows($response) > 0) {
        header("Location: home.html");
        exit; // Make sure to exit after a header redirect
    }
} else {
    // Handle SQL query error
    echo "<script> alert('username and password are incorrect or signup ');
    location href='index.html';
    </script>";
}

$conn->close();
?>
