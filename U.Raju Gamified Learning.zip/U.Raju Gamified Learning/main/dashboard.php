<?php
        include("database.php");
        $useri = $_POST['username'];
        $userp = $_POST['password'];
        $sql = "select * from signup where username = '$useri' and password= '$userp'";
        $result=mysqli_query($conn,$sql);
        $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
        $count=mysqli_num_rows($result);
        if($count==1)
        {
            echo '<script>alert("Login sucess")</script>';
            header("Location: dashboard.html");
            exit();
        }
        else{
            echo '<script>alert("Invalid details")</script>';
        
        }
?>
